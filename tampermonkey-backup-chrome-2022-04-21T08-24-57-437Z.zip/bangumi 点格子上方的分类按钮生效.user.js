// ==UserScript==
// @name         bangumi 点格子上方的分类按钮生效
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  喵喵
// @author       鈴宮華緋
// @include      /https?:\/\/(bgm\.tv|bangumi\.tv|chii\.in)\/$/
// ==/UserScript==

(function() {
    let btns = $("#prgCatrgoryFilter").find("a");
    let subjects = $("#prgManagerMain").find(".infoWrapper");
    btns.click(function() {
        let subject_type = $(this).attr("subject_type");
        let num = 0;
        for(let i=0;i < subjects.length;i++) {
            let subject = subjects.eq(i);
            if(subject.attr("subject_type") != subject_type && subject_type != 0) {
                subject.hide();
            } else {
                subject.show();
                num++;
                if(num % 2 != 0) {
                    subject.addClass("odd");
                } else {
                    subject.removeClass("odd");
                }
            }
        }
    });
})();