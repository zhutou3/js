// ==UserScript==
// @name         【科学上网】【订阅链接】：ss/ssr/v2ray/Trojan节点==>v2ray&clash订阅【订阅集合】Stable版
// @name:en      【科学上网】【订阅链接】：ss/ssr/v2ray/Trojan节点==>v2ray&clash订阅
// @name:zh-TW   【科学上网】【订阅链接】：ss/ssr/v2ray/Trojan节点==>v2ray&clash订阅
// @name:zh-HK   【科学上网】【订阅链接】：ss/ssr/v2ray/Trojan节点==>v2ray&clash订阅
// @namespace    http://tampermonkey.net/
// @version      3.10.0.1
// @description  This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @description:en  We share v2ray&clash subscription link here, including ss/ssr/v2ray/Trojan node. Usage: 1. Open the Baidu homepage, log out, right click to copy the corresponding link to import the corresponding client, and update the subscription. 2. Open bing.com, the following steps are the same as method 1
// @description:zh-TW 分享v2ray&clash订阅链接，包含ss/ssr/v2ray/Trojan节点。使用方法：1.打开百度首页，退出登录，右键复制相应链接导入相应客户端，更新订阅。2.打开bing.com，后面步骤同方法1
// @description:zh-HK 分享v2ray&clash订阅链接，包含ss/ssr/v2ray/Trojan节点。使用方法：1.打开百度首页，退出登录，右键复制相应链接导入相应客户端，更新订阅。2.打开bing.com，后面步骤同方法1
// @author       hello world
// @match        https://www.baidu.com/
// @match        *.bing.com/
// @include      https://www.baidu.com/
// @include      *.bing.com/
// ==/UserScript==
